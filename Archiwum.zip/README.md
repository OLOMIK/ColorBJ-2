# ColorBJ 2 (15.0)
We implemented completly new React UI, refactored code
comming soon
